# Lo-fi wildfire assets

Open the [interactive preview](http://127.0.0.1:4173/visual-assets/) while the local prototype is running (`npm start` from the project folder). Click the cloud for a short shower, hold for continued rain, or play and scrub the forest transition. Space and Enter also trigger rain. Reduced-motion settings offer static states.

The visual language uses spare ink silhouettes, low flames at ground level, thin blue rain strokes, and drifting gray smoke. Charred trunks, fallen branches, and ash remain visible after the heat is gone. Cooling does not restore trees or turn burned ground green.

## Files

| File in `exports/` | Use |
| --- | --- |
| `asset-sheet.png` | Overview of rainfall and all forest states |
| `rainfall.png` | Transparent cloud and rain frame |
| `surface-fire.png` | Transparent forest, low flames, and smoke |
| `embers.png` | Transparent forest, residual glow, and smoke |
| `out-burned-remains.png` | Transparent burned forest and land, without fire or glow |
| `rainfall.gif` | 4.2-second rain loop |
| `forest-transition.gif` | Plays once: 18-second cooling transition, 3-second smoke tail, then 1.5 seconds holding the burned remains |
| `forest-transition-spritesheet.png` | 12 frames in reading order, 4 columns × 3 rows; each cell is 640 × 360 pixels |
| `wildfire-lofi-assets.zip` | Packaged asset handoff |

The PNG files preserve transparency. GIFs use a paper-colored background; use `renderer.js` when smooth timing and transparency are required. The 18-second sequence is an asset demonstration, not the duration of cooling in the performance simulation.

## Reusable renderer

`renderer.js` is an ES module with no external dependencies. It exports `drawForest`, `drawCloudRain`, and the frozen `palette` object. Both drawing functions accept a Canvas 2D context, preserve its state, and clip their output to the supplied rectangle. They do not clear the canvas. Clear it before each animation frame; call repeatedly from `requestAnimationFrame` with time in seconds.

```js
import { drawForest, drawCloudRain } from './visual-assets/renderer.js';

drawCloudRain(ctx, {
  x: 0, y: 0, width: 640, height: 360,
  time: performance.now() / 1000, amount: 1,
});

drawForest(ctx, {
  x: 0, y: 0, width: 640, height: 360,
  time: performance.now() / 1000, progress: 0.62,
});
```

Shared options are `x`, `y`, `width`, `height`, `time`, `seed`, and `background`. `background` defaults to `false` for transparency; use `true` for the palette's paper color or supply a CSS color. Stable seeds keep particle positions consistent across frames. Geometry uses a 640 × 360 coordinate space scaled into the requested rectangle.

`drawCloudRain` defaults to a 320 × 300 box. `amount` ranges from 0 to 1 and controls active rain. On release, set `amount: 0` and reduce `tail` from 1 to 0 over about 0.8 seconds so the remaining drops settle. The cloud remains visible when idle. Its silhouette occupies approximately the central half of the rectangle's width; drops fall below it.

`drawForest` defaults to a 640 × 360 box. Supply `progress` for an art-directed sequence: `0` is surface fire, approximately `0.55–0.62` is embers, and `1` is out. `smokeTail` ranges from 1 to 0 for lingering smoke at the end; the preview fades it over 3 seconds. Keep it at 0 for a fully still out frame.

For live performance state, omit `progress`:

```js
drawForest(ctx, {
  width: 640, height: 360, time: performance.now() / 1000,
  heat: cell.heat,
  surfaceWetness: cell.surfaceWetness,
  extinguished: cell.extinguished,
  smokeTail: 0,
});
```

`heat` and `surfaceWetness` range from 0 to 1. Wetness suppresses surface flames quickly; residual heat continues to drive ember glow and smoke. `extinguished: true` removes all flame and ember glow. A caller-controlled `smokeTail` can then let smoke fade away. The burned structure stays fixed through wetting, drying, and reheating.

## Palette and prototype integration

Core colors are paper `#faf9f5`, ink `#333632`, charcoal `#393b38`, ash `#c5c3bc`, smoke `#8e938e`, fire `#a44832`, ember `#ba852b`, and rain `#548fb7`. Shapes carry the state alongside color: rising flames, low glowing marks, then ash and charred remains.

The main map replaces thermal-detection dots with one forest-and-land glyph per source-containing 0.25-degree simulation cell. Each glyph follows its own heat, wetness, and extinction state directly where rain falls. Nearby cells are not averaged into a shared visual state. Original observation details remain available for inspection.

`map-forest.js` exports `drawMapForest(ctx, {x, y, scale, time, heat, surfaceWetness, extinguished, smokeTail, tailHeat, seed, layer})` and `forestPatchBounds({x, y, scale, seed, layer})`. Here `scale` is projected pixels per degree, and `x/y` is the projected cell center. Stable seeds vary organic ground shapes, tree placement, height, lean, branching, and stumps. Terrain grows with zoom; fire and smoke keep a gentle minimum readable size in wide views. Paint all patches' `terrain` layers first, then their `fire` layers, then `smoke`, to avoid neighboring ground hiding the effects. Omit `layer` or use `all` to draw one complete patch. Use terrain bounds for hit testing and full bounds for culling. On extinction, retain the previous heat in `tailHeat` and fade `smokeTail` from 1 to 0 over three seconds; model heat itself becomes zero.

`map-weather.js` exports `drawBrushRain(ctx, {x, y, radius, time, amount, tail, tailAmount, seed})` and `brushRainBounds({x, y, radius})`. Set `radius` to the projected geographic brush radius. The cloud spans the circle above it; rain falls freely as a full-width curtain, with wind drift and varied landings beyond the circle. `brushRainBounds` returns the exact brush `footprint` separately from the expanded `rain` and cloud bounds. On release, set `amount: 0`, retain the released strength in `tailAmount`, and fade `tail` from 1 to 0 over 0.8 seconds.

Forest imagery is a schematic performance layer: it does not assert that a satellite detection is forest, define a real fire boundary, or measure burned extent. Source observations and the cooling simulation remain separate.
